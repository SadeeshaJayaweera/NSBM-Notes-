#include <stdio.h>
#include <stdlib.h>

int main()
{
    /*
    Display the following output using printf() statements
    *
    **
    ***
    ****
    *****
    */
    printf("*\n**\n***\n****\n*****\n");

    return 0;
}
