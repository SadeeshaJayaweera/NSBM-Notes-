#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Input two integers and display the total

    int num_1, num_2;

    printf("Enter Number 1: ");
    scanf("%d", &num_1);

    printf("Enter Number 2: ");
    scanf("%d", &num_2);

    printf("Total = %d", num_1+num_2);
    return 0;
}
