#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Display your name and school name in two separate lines

    printf("Your Name\nSchool Name");

    // or
    /*
    printf("Your Name\n");
    printf("School Name\n")
    */
    return 0;
}
